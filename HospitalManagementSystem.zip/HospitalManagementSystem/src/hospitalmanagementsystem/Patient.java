package hospitalmanagementsystem;

public class Patient extends Person {
    private String condition;

    // Constructor
    public Patient() {
        super();
    }

    // Getter and setter for 'condition'
    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }
}