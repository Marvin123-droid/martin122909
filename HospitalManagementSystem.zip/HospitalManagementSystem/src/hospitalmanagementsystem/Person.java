package hospitalmanagementsystem;

class Person {
    private String name;
    private int age;

    // Constructor
    public Person() {
    }

    // Getter and setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Protected method to display person details
    protected void displayDetails() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}