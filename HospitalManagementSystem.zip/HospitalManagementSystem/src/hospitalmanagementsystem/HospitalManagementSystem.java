package hospitalmanagementsystem;

import java.util.Scanner;

public class HospitalManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input for Doctor
        Doctor doc = new Doctor();
        System.out.println("Enter Doctor's Name:");
        doc.setName(scanner.nextLine());
        System.out.println("Enter Doctor's Age:");
        doc.setAge(scanner.nextInt());
        scanner.nextLine(); // Consume newline left-over
        System.out.println("Enter Doctor's Specialization:");
        doc.setSpecialization(scanner.nextLine());

        // Input for Patient
        Patient pat = new Patient();
        System.out.println("Enter Patient's Name:");
        pat.setName(scanner.nextLine());
        System.out.println("Enter Patient's Age:");
        pat.setAge(scanner.nextInt());
        scanner.nextLine(); // Consume newline left-over
        System.out.println("Enter Patient's Condition:");
        pat.setCondition(scanner.nextLine());

        // Creating hospital instance and setting references
        Hospital hospital = new Hospital();
        hospital.setDoctor(doc);
        hospital.setPatient(pat);

        // Displaying details
        hospital.displayHospitalDetails();

        scanner.close();
    }
}
