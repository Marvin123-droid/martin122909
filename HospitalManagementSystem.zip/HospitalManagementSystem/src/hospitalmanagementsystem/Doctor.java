package hospitalmanagementsystem;

public class Doctor extends Person {
    private String specialization;

    // Constructor
    public Doctor() {
        super();
    }

    // Getter and setter for 'specialization'
    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }
}
