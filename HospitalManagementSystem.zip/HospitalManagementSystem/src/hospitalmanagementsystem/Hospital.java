package hospitalmanagementsystem;

public class Hospital {
    private Doctor doctor;
    private Patient patient;

    // Methods to set references
    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    // Method to display hospital details
    public void displayHospitalDetails() {
        System.out.println("Hospital Details:");
        if (doctor != null) {
            System.out.print("Doctor: ");
            doctor.displayDetails();
        }
        if (patient != null) {
            System.out.print("Patient: ");
            patient.displayDetails();
        }
    }
}