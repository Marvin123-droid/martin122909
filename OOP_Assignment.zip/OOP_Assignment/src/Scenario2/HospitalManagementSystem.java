package Scenario2;

import java.util.Scanner;

public class HospitalManagementSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a patient object
        Patient patient = new Patient();

        // Input age from the user
        System.out.print("Enter patient's age: ");
        int age = scanner.nextInt();

        // Try setting the age of the patient object
        try {
            patient.setAge(age);
            System.out.println("Patient's age set successfully to: " + patient.getAge());
        } catch (InvalidAgeException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
