package Scenario1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SchoolManagementSystem {
    private List<Student> students;
    private Scanner scanner;

    public SchoolManagementSystem() {
        students = new ArrayList<>();
        scanner = new Scanner(System.in);
    }

    public void assignGrade(String studentName, int grade) {
        try {
            if (grade < 0 || grade > 100) {
                throw new IllegalArgumentException("Invalid grade: " + grade);
            }
            Student student = findStudent(studentName);
            if (student == null) {
                student = new Student(studentName);
                students.add(student);
            }
            student.setGrade(grade);
            System.out.println("Grade assigned successfully to " + studentName);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        } finally {
            System.out.println("Grade assignment attempted for " + studentName);
        }
    }

    private Student findStudent(String studentName) {
        for (Student student : students) {
            if (student.getName().equals(studentName)) {
                return student;
            }
        }
        return null;
    }

    public void inputGradesFromUser() {
        String studentName;
        int grade;

        System.out.println("Enter student names and grades. Enter 'exit' to finish.");
        while (true) {
            System.out.print("Student name: ");
            studentName = scanner.nextLine();
            if (studentName.equalsIgnoreCase("exit")) {
                break;
            }
            System.out.print("Grade: ");
            try {
                grade = Integer.parseInt(scanner.nextLine());
                assignGrade(studentName, grade);
            } catch (NumberFormatException e) {
                System.err.println("Invalid grade input. Please enter a number.");
            }
        }
    }

    public static void main(String[] args) {
        SchoolManagementSystem sms = new SchoolManagementSystem();
        sms.inputGradesFromUser();
    }
}